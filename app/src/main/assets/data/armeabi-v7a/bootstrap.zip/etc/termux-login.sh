##
## This script is sourced by /data/data/com.itsaky.androidide/files/usr/bin/login before executing shell.
##
